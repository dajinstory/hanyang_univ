# Numerical Analysis

## hw5
- solve Ax=b
- Gauss-Jordan Elimination, LU Decomposition, SVD, mprove

#### Quick Start
```
cd hw5
gcc -o main main.c -lm
./main
```

#### Report
- Compare each methods
```
Gauss-Jordan Elimination의 경우 역행렬이 존재하지 않는 경우, 답을 구할 수 없다는 단점이 존재함을 확인했습니다. 근사한 답이거나, 답 관련된 식에 대한 접근이 불가능했습니다. 
```